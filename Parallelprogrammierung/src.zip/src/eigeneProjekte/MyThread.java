package eigeneProjekte;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

class MyRunnable implements Runnable {
    private int[] m_Array;
    private int swapCount = 0;
    private long elapsedTime = -1;

    public MyRunnable(int[] array) {
        this.m_Array = array;
    }

    @Override
    public void run() {
        initiateSorting();
    }

    private void initiateSorting() {
        long startTime = System.nanoTime();
        initiateBubbleSort();
        long endTime = System.nanoTime();
        elapsedTime = endTime - startTime;
    }

    private void initiateBubbleSort() {
        for (int i1 = 1; i1 < m_Array.length; ++i1) {
            for (int i2 = 0; i2 < m_Array.length - i1; ++i2) {
                if (m_Array[i2] > m_Array[i2 + 1]) {
                    incrementSwapCount();
                    swap(m_Array, i2, i2 + 1);
                }
            }
        }
    }

    private void swap(int[] array, int iPos1, int iPos2) {
        int tmp = array[iPos1];
        array[iPos1] = array[iPos2];
        array[iPos2] = tmp;
    }

    private void incrementSwapCount() {
        ++swapCount;
    }

    public int getSwapCount() {
        return swapCount;
    }

    public long getElapsedTime() {
        return elapsedTime;
    }
}

public class MyThread {
    public static void main(String... args) {
        //System.out.println("Hello World!");
        runSortingTask();
    }

    private static void runSortingTask() {
        int[] sizes = getArraySizes();
        List<Thread> threads = new ArrayList<>();
        List<MyRunnable> runnables = new ArrayList<>();

        createAndStartThreads(sizes, threads, runnables);
        waitForThreads(threads);
        printResults(sizes, runnables);
    }

    private static int[] getArraySizes() {
        return new int[]{100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000};
    }

    private static void createAndStartThreads(int[] sizes, List<Thread> threads, List<MyRunnable> runnables) {
        for (int i = 0; i < sizes.length; ++i) {
            int[] array = generateRandomArray(sizes[i]);
            MyRunnable runnable = new MyRunnable(array);
            Thread thread = new Thread(runnable);
            threads.add(thread);
            runnables.add(runnable);
            thread.start();
        }
    }

    private static void waitForThreads(List<Thread> threads) {
        for (int i = 0; i < threads.size(); ++i) {
            try {
                threads.get(i).join();
            } catch (InterruptedException e) {
                System.err.println("Thread interrupted: " + e.getMessage());
            }
        }
    }

    private static void printResults(int[] sizes, List<MyRunnable> runnables) {
        System.out.println("| Array size   | Swap count   | Sorting time (ns) |");
        System.out.println("|--------------|--------------|--------------------|");
        for (int i = 0; i < runnables.size(); ++i) {
            MyRunnable runnable = runnables.get(i);
            System.out.printf("| %-12d | %-12d | %-18d |\n",
                    sizes[i], runnable.getSwapCount(), runnable.getElapsedTime());
        }
    }

    public static int[] generateRandomArray(int size) {
        int[] temp = new int[size];
        for (int i = 0; i < temp.length; ++i)
            temp[i] = ThreadLocalRandom.current().nextInt(-100000, 100000);
        return temp;
    }
}