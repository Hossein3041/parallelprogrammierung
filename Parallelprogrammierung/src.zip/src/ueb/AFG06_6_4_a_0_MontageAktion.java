package ueb;

public class AFG06_6_4_a_0_MontageAktion implements Runnable{
    @Override
    public void run(){
        System.out.println(">>> Montage startet! Teile montiert.");
    }
}
