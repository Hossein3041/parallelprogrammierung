package aufgabe_1_3_wdh;

public class Steuerung {
    private final int M;
    private final int T;
    private int resetPlaetze = 0;
    private int SLEEPTIME = 1000;
    private int[][] wagonAndPassengers;
    private final int passengers, position;
    private final int startPos;

    public Steuerung(int M, int T) {
        this.M = M;
        this.T = T;
        this.passengers = 0;
        this.position = 1;
        this.startPos = T - 1;
        this.wagonAndPassengers = new int[T][2];
        for (int i = 0, j = startPos; i < T; ++i, --j)
            wagonAndPassengers[i][position] = j;
    }

    public synchronized void passagier() throws InterruptedException {
        int pos;
        while (!(wagonAndPassengers[pos = (int) (Math.random() * T)][passengers] < M)) {
            boolean flag = false;
            for (int i = 0; i < T; ++i)
                if (!(wagonAndPassengers[i][passengers] == M)) flag = true;
            if (flag == false) wait();
        }
        wagonAndPassengers[pos][passengers]++;
        System.out.printf("Passagier: %s (Wagen: %s)\n", wagonAndPassengers[pos][passengers], pos + 1);
        notifyAll();
    }

    public synchronized void abfahrt(int n) throws InterruptedException {
        while (!(wagonAndPassengers[n - 1][position] == startPos && wagonAndPassengers[n - 1][passengers] == M)) wait();
        System.out.printf("Abfahr Wagen: %s\n", n);
        Thread.sleep(SLEEPTIME);
        notifyAll();
    }

    public synchronized void aussteigen(int wagonnumber) throws InterruptedException {
        System.out.println("aussteigen");
        Thread.sleep(SLEEPTIME);
        wagonAndPassengers[wagonnumber - 1][passengers] = resetPlaetze;
        for (int i = 0; i < T; ++i)
            wagonAndPassengers[i][position] = (wagonAndPassengers[i][position] + 1) % T;
        notifyAll();
    }
}
