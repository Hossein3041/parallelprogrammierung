package aufgabe_1_3_wdh;

public class Wagen implements Runnable {
    private final int n;
    private Steuerung steuerung;
    private int SLEEPTIME = 500;

    public Wagen(int n, Steuerung obj) {
        this.n = n;
        this.steuerung = obj;
    }

    @Override
    public void run() {
        Achterbahn.printThreadData(n);
        while (true) {
            try {
                steuerung.abfahrt(n);
                System.out.println("unterwegs");
                Thread.sleep(SLEEPTIME);
                steuerung.aussteigen(n);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
