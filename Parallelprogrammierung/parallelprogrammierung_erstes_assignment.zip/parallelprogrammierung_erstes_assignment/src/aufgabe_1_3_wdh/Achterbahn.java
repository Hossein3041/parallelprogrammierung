package aufgabe_1_3_wdh;

import java.util.Scanner;

public class Achterbahn {
    private static int M;
    private static int T;

    public static void setEingaben() {
        boolean inputAccepted = false;
        Scanner sc = new Scanner(System.in);
        while (!inputAccepted) {
            try {
                System.out.print("Anzahl Passagiere M pro Wagen festlegen: ");
                M = Integer.valueOf(sc.nextLine());
                if (M >= 1) inputAccepted = !inputAccepted;
            } catch (NumberFormatException e) {
                System.out.println("Ungültige Eingabe!");
            }
        }

        try {
            System.out.print("Anzahl Wagen T festlegen: ");
            T = Integer.valueOf(sc.nextLine());
            if (!(T >= 1 && T <= 10)) {
                T = 3;
                System.out.println("Default Wert: 3");
            }
        } catch (NumberFormatException e) {
            T = 3;
            System.out.println("Default Wert: 3");
        }

        sc.close();
    }

    public static void printThreadData(Integer n) {
        System.out.printf("Instanz(%s): %s\n", n, Thread.currentThread().toString());
    }

    public static void main(String... args) {
        setEingaben();
        printThreadData(0);

        Steuerung steuerung = new Steuerung(M, T);
        for (int i = 1; i <= T; ++i)
            (new Thread(new Wagen(i, steuerung), "Wagen")).start();
        (new Thread(new Drehkreuz(T + 1, steuerung), "Drehkreuz")).start();
    }
}
