package aufgabe1_2;

import java.util.Scanner;

public class Achterbahn {
    //Anzahl Passagiere M pro Wagen 
    private static int M;
    private static int SLEEPTIME = 100;

    public static void setEingabe() {
        //Scanner-Objekt sc initialisiert M per Tastatureingabe
        boolean inputAccepted = false;
        Scanner sc = new Scanner(System.in);

        //gültige Werte sind positive Ganzahlen (ohne Null)
        while (!inputAccepted) {
            try {
                System.out.print("Anzahl Passagiere M pro Wagen festlegen: ");
                M = Integer.valueOf(sc.nextLine());
                if (M >= 1) inputAccepted = !inputAccepted;
            } catch (NumberFormatException e) {
                System.out.println("Ungültige Eingabe!");
            }
        }
        sc.close();
    }

    public static void printThreadData(Integer n) {
        //Ausgabe der Thread-Daten
        System.out.printf("Instanz(%s): %s\n", n, Thread.currentThread().toString());
//        try {
//            Thread.sleep(SLEEPTIME);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }

    public static void main(String... args) {
        setEingabe();
        printThreadData(0);
        
        //erstellt Steuerungs-Objekt + Runnables und startet die Threads
        Steuerung steuerung = new Steuerung(M);
        for(int i = 1; i < 4; ++i) {
            (new Thread(new Wagen(i, steuerung), "Wagen")).start();
        }
        (new Thread(new Drehkreuz(4, steuerung), "Drehkreuz")).start();
    }
}
