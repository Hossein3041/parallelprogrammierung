package aufgabe1_2;

public class Steuerung {
    //Anzahl Passagiere M pro Wagen
    private final int passengers, position;
    private int M;
    private int resetPlaetze = 0;
    //aktuelle Anzahl Passagiere
    private int plaetze;
    private int SLEEPTIME = 1000;
    // Anzahl der aktuell in den Wagen sitzenden Passagiere und die Position der stehenden Wagen
    private int[][] wagonAndPassengers;

    public Steuerung(int M) {
        this.passengers = 0;
        this.position = 1;
        this.M = M;
        this.plaetze = 0;
        // [x][passengers] = Anzahl Passagiere; [x][position] = Stellplatz des Wagens
        this.wagonAndPassengers = new int[3][2];
        // Die Wagen 1-3 gehen an Index 0-2
        for (int i = 0, j = 2; i < 3; ++i, --j) {
            wagonAndPassengers[i][position] = j;
        }
    }

    public synchronized void passagier() throws InterruptedException {
        //solange Plätze in dem Wagen frei sind, darf das Drehkreuz einzelne Passagiere schicken
        int pos;
        while (!(wagonAndPassengers[pos=(int)(Math.random() * 3)][passengers] < M));// wait();
        wagonAndPassengers[pos][passengers]++;
        System.out.printf("Passagier: %s (Wagen: %s)\n", wagonAndPassengers[pos][passengers], pos+1);
        notifyAll();
    }

    public synchronized void abfahrt(int n) throws InterruptedException {
        //ist M erreicht, darf der Wagen abfahren
        while (!(wagonAndPassengers[n-1][position] == 2 && wagonAndPassengers[n-1][passengers] == M)) wait();
        System.out.printf("Abfahrt Wagen: %s\n", n);
        Thread.sleep(SLEEPTIME);
        notifyAll();
    }

    public synchronized void aussteigen(int wagonnumber) throws InterruptedException {
        //erst nachdem der Wagen aussteigen aufruft, darf der aktuelle Passagier-Wert auf Null gesetzt werden
        System.out.println("aussteigen");
        Thread.sleep(SLEEPTIME);
        // Wagen 1 (0 im array) mit Positionswert 2 fährt zuerst los -> Kommt zurück; Alle Wagen inkrementieren ihren Positionswert um 1
        wagonAndPassengers[wagonnumber-1][passengers] = 0;
        for (int i = 0; i < 3; ++i) {
            System.out.println("Alte Position:" + wagonAndPassengers[i][position]);
            wagonAndPassengers[i][position] = (wagonAndPassengers[i][position] + 1) % 3;
            System.out.println("Neue Position:" + wagonAndPassengers[i][position]);
        }
        notifyAll();
    }
}
