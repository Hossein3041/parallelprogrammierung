public class Wagen implements Runnable {

    private final int n;
    private Steuerung steuerung;

    public Wagen(int n, Steuerung obj) {
        this.n = n; 
        this.steuerung = obj;
    }

    @Override
    public void run() {
        Achterbahn.printThreadData(n);
        while(true){
            try {
            steuerung.abfahrt();
            System.out.println("unterwegs");
            Thread.sleep(1000);
            steuerung.aussteigen();
            } catch (InterruptedException e) {
            e.printStackTrace();
            }
        }
  
    }
}