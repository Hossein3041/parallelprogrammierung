import java.util.Scanner;

public class Achterbahn {

    //Anzahl Passagiere M pro Wagen 
    private static int M;

    public static void setEingabe() {
        //Scanner-Objekt sc initialisiert M per Tastatureingabe
        //gültige Werte sind posivitve Ganzahlen (ohne Null)
        boolean inputAccepted = false;
        Scanner sc = new Scanner(System.in);

        while (!inputAccepted) {
            try {
                System.out.print("Anzahl Passagiere M pro Wagen festlegen: ");
                M = Integer.valueOf(sc.nextLine());
                if (M >= 1) {inputAccepted = true;}
            } catch (NumberFormatException e) {
                System.out.println("Ungültige Eingabe!"); 
            }
        }
         sc.close(); 
    } 
    
    public static void printThreadData(Integer n) {
        System.out.printf("Instanz(%s): %s\n", n, Thread.currentThread().toString());
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String... args) {
        setEingabe();
        printThreadData(0);
        Steuerung steuerung = new Steuerung(M);
        Thread myFirst = new Thread(new Wagen(1,steuerung), "Wagen");
        Thread mySecond = new Thread(new Drehkreuz(2,steuerung), "Drehkreuz");
        myFirst.start(); mySecond.start();
        }
    }